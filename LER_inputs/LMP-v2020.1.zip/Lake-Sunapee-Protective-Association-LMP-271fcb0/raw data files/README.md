## README 

This folder contains the raw, non-QAQC'd, non-collated LMP data from the LSPA. Please use the [master files](https://github.com/Lake-Sunapee-Protective-Association/LMP/tree/main/master%20files) instead of these. If you have any questions, please contact Bethel Steele (steeleb@caryinstitute.org).